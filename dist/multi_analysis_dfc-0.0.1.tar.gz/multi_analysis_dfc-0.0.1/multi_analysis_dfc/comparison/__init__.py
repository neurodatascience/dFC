"""The dFC multi_analysis toolbox."""

from .similarity_assessment import SimilarityAssessment


__all__ = [
    'SimilarityAssessment', 
]
