# dFC
an implementation of several well-known dynamic Functional Connectivity assessment methods.

Simply run all the code cells in demo_code to learn how to use the dFC functions. 
